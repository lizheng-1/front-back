# 导入MiddlewareMixin用于创建自定义中间件
from django.utils.deprecation import MiddlewareMixin
# 导入DRF的认证头处理函数
from rest_framework.authentication import get_authorization_header
# 引入DRF的异常处理
from rest_framework import exceptions
# 导入jwt库用于解码jwt令牌
import jwt
# 从项目配置中获取SECRET_KEY
from django.conf import settings
# 获取用户模型
from django.contrib.auth import get_user_model
# 引入JsonResponse用于返回JSON响应
from django.http.response import JsonResponse
# 引入HTTP状态码
from rest_framework.status import HTTP_403_FORBIDDEN
# 引入jwt的过期异常处理
from jwt.exceptions import ExpiredSignatureError
# 匿名用户模型
from django.contrib.auth.models import AnonymousUser

# 获取项目的用户模型
OAUser = get_user_model()


# 定义登录检查中间件
class LoginCheckMiddleware(MiddlewareMixin):
    # 设置JWT关键字，用于从请求头中识别JWT令牌
    keyword = "JWT"

    def __init__(self, *args, **kwargs):
        # 调用父类初始化方法
        super().__init__(*args, **kwargs)
        # 定义白名单，列出不需要登录验证的URL路径
        self.white_list = ['/auth/login', '/auth/ ']  # 注意这里的'/auth/ '似乎多了一个空格，可能是笔误

    # 处理视图函数前的逻辑
    def process_view(self, request, view_func, view_args, view_kwargs):
        # 如果请求的URL在白名单内
        if request.path in self.white_list:
            # 将匿名用户和无认证信息绑定到请求对象上
            request.user = AnonymousUser()
            request.auth = None
            # 直接返回None，继续执行视图函数
            return None

        # 尝试从请求头中获取JWT令牌
        try:
            auth = get_authorization_header(request).split()

            # 验证JWT令牌的存在性及其关键字正确性
            if not auth or auth[0].lower() != self.keyword.lower().encode():
                raise exceptions.ValidationError("请传入JWT！")

            # 检查JWT格式，排除无效情况
            if len(auth) == 1:
                raise exceptions.AuthenticationFailed("不可用的JWT请求头！")
            elif len(auth) > 2:
                raise exceptions.AuthenticationFailed('不可用的JWT请求头！JWT Token中间不应该有空格！')

            # 尝试解码JWT令牌
            jwt_token = auth[1]
            jwt_info = jwt.decode(jwt_token, settings.SECRET_KEY, algorithms='HS256')
            userid = jwt_info.get('userid')

            # 尝试根据userid获取用户对象并绑定到请求上
            try:
                user = OAUser.objects.get(pk=userid)
                request.user = user
                request.auth = jwt_token
            except:
                # 用户不存在时抛出异常
                raise exceptions.AuthenticationFailed("用户不存在！")

        except ExpiredSignatureError:
            # 处理JWT过期的情况
            raise exceptions.AuthenticationFailed("JWT Token已过期！")
        except Exception as e:
            # 捕获其他所有异常，并返回未登录的错误信息
            print(e)  # 打印异常信息便于调试
            return JsonResponse(data={"detail": "请先登录！"}, status=HTTP_403_FORBIDDEN)