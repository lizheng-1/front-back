# 导入必要的Django模块和第三方库ShortUUIDField用于生成短UUID作为主键

from django.db import models
from django.contrib.auth.models import User, AbstractBaseUser, PermissionsMixin, BaseUserManager
from django.contrib.auth.hashers import make_password
from shortuuidfield import ShortUUIDField

# 定义用户状态的选择枚举，包括已激活、未激活和被锁定三种状态
class UserStatusChoices(models.IntegerChoices):
    # 已经激活的
    ACTIVED = 1
    # 没有激活
    UNACTIVE = 2
    # 被锁定
    LOCKED = 3
# 自定义用户管理器，继承自BaseUserManager，用于处理用户创建逻辑
class OAUserManager(BaseUserManager):
    use_in_migrations = True

    # 内部方法，用于实际创建用户记录
    def _create_user(self, realname, email, password, **extra_fields):
        if not realname:
            raise ValueError("必须设置真实姓名！")
        email = self.normalize_email(email)  # 标准化邮箱格式
        user = self.model(realname=realname, email=email, **extra_fields)
        user.password = make_password(password)  # 使用Django的密码哈希函数加密密码
        user.save(using=self._db)  # 保存到数据库
        return user

    # 创建普通用户的方法
    def create_user(self, realname, email=None, password=None, **extra_fields):
        extra_fields.setdefault("is_staff", False)  # 默认普通用户不是staff
        extra_fields.setdefault("is_superuser", False)  # 默认不是超级用户
        return self._create_user(realname, email, password, **extra_fields)

    # 创建超级用户的方法
    def create_superuser(self, realname, email=None, password=None, **extra_fields):
        extra_fields.setdefault("is_staff", True)  # 确保超级用户是staff
        extra_fields.setdefault("is_superuser", True)  # 确保是超级用户
        extra_fields.setdefault('status', UserStatusChoices.ACTIVED)  # 设置默认状态为已激活
        # 验证超级用户的必要条件
        if not extra_fields.get("is_staff"):
            raise ValueError("超级用户必须设置is_staff=True.")
        if not extra_fields.get("is_superuser"):
            raise ValueError("超级用户必须设置is_superuser=True.")
        return self._create_user(realname, email, password, **extra_fields)

# 自定义用户模型，继承AbstractBaseUser和PermissionsMixin，以支持权限和扩展字段
class OAUser(AbstractBaseUser, PermissionsMixin):
    """
    自定义的User模型，包含uid(短UUID主键), 真实姓名, 邮箱, 电话, 是否为员工, 用户状态, 是否激活, 注册时间, 所属部门等字段。
    """
    uid = ShortUUIDField(primary_key=True)  # 使用ShortUUID作为唯一标识符
    realname = models.CharField(max_length=150, unique=False)  # 真实姓名
    email = models.EmailField(unique=True, blank=False)  # 邮箱，唯一且必填
    telephone = models.CharField(max_length=20, blank=True)  # 电话号码
    is_staff = models.BooleanField(default=True)  # 是否为员工，默认是
    status = models.IntegerField(choices=UserStatusChoices.choices, default=UserStatusChoices.UNACTIVE)  # 用户状态，默认未激活
    is_active = models.BooleanField(default=True)  # 是否激活，默认激活（此字段与status功能重叠，需根据实际情况使用）
    date_joined = models.DateTimeField(auto_now_add=True)  # 注册时间，自动添加

    # 关联到部门模型，一个用户属于一个部门
    department = models.ForeignKey('OADepartment', null=True, on_delete=models.SET_NULL, related_name='staffs', related_query_name='staff')

    objects = OAUserManager()  # 使用自定义的用户管理器

    EMAIL_FIELD = "email"
    # USERNAME_FIELD：是用来做鉴权的，会把authenticate的username参数，传给USERNAME_FIELD指定的字段
    # from django.contrib.auth import authenticate
    USERNAME_FIELD = "email"
    # REQUIRED_FIELDS：指定哪些字段是必须要传的，但是不能重复包含USERNAME_FIELD和EMAIL_FIELD已经设置过的值
    REQUIRED_FIELDS = ["realname", 'password']

    # 重写clean方法，标准化电子邮件地址
    def clean(self):
        super().clean()
        self.email = self.__class__.objects.normalize_email(self.email)

    # 获取用户全名和简称的方法，默认返回真实姓名
    def get_full_name(self):
        return self.realname

    def get_short_name(self):
        return self.realname

# 部门模型，包含名称、简介、领导和管理员等字段
class OADepartment(models.Model):
    name = models.CharField(max_length=100)  # 部门名称
    intro = models.CharField(max_length=200)  # 部门简介
    # 一个部门一个领导 ，一对一关联到OAUser，允许为空
    leader = models.OneToOneField(OAUser, null=True, on_delete=models.SET_NULL, related_name='leader_department', related_query_name='leader_department')
    # 一个人可以分管多个部门 ，一对多关联到 OAUser，允许为空
    manager = models.ForeignKey(OAUser, null=True, on_delete=models.SET_NULL, related_name='manager_departments', related_query_name='manager_departments')