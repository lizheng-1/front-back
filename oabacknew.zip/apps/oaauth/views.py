# 导入必需的模块和自定义组件
from django.shortcuts import render
from rest_framework.views import APIView
from .serializers import LoginSerializer, UserSerializer
from datetime import datetime
from .authentications import generate_jwt  # 用于生成JWT的函数
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated  # 权限类，用于要求用户必须经过身份验证
from .serializers import ResetPwdSerializer  # 重置密码序列化器
from rest_framework import status  # 导入HTTP状态码模块

# 登录视图，处理用户登录逻辑
class LoginView(APIView):
    def post(self, request):
        # 1. 使用LoginSerializer 验证数据是否可用
        serializer = LoginSerializer(data=request.data)
        if serializer.is_valid():  # 验证数据是否符合序列化器的要求
            # 从验证后的数据中获取用户对象
            user = serializer.validated_data.get('user')
            # 更新用户的最后登录时间
            user.last_login = datetime.now()
            user.save()
            # 生成JWT令牌
            token = generate_jwt(user)
            # 返回成功响应，包含JWT令牌和用户基本信息（已序列化）
            # return Response({'token': token})
            return Response({'token': token, 'user': UserSerializer(user).data})
        else:  # 数据验证失败时
            # 提取错误信息中的第一条错误详情
            detail = list(serializer.errors.values())[0][0]
            print(detail)
            # 返回错误响应，状态码400表示客户端错误
            return Response({"detail": detail}, status=status.HTTP_400_BAD_REQUEST)


class GetinfoView(APIView):
    def post(self, request):
        # 1. 使用LoginSerializer 验证数据是否可用
        serializer = LoginSerializer(data=request.data)
        if serializer.is_valid():  # 验证数据是否符合序列化器的要求
            # 从验证后的数据中获取用户对象
            user = serializer.validated_data.get('user')
            # 更新用户的最后登录时间
            user.last_login = datetime.now()
            user.save()
            # 返回成功响应，包含JWT令牌和用户基本信息（已序列化）
            return Response({'user': UserSerializer(user).data})


# 重置密码视图，处理用户密码重置逻辑
class ReinitPwdView(APIView):
    def post(self, request):
        print(request)
        print(request.user)
        return Response({"detail": "sucess"})  # 返回错误响应，状态码400

# 注释掉了原本的AuthenticatedRequiredView类，但下面的ResetPwdView使用了权限控制
# 一般情况下，会有一个基类用于定义通用权限，然后其他视图根据需要继承这个基类

# 重置密码视图，处理用户密码重置逻辑
class ResetPwdView(APIView):
    def post(self, request):
        # 显式导入Request，虽然此处未直接使用，但说明了request的类型
        # 实际上request已经是DRF的Request对象，无需再次转换
        serializer = ResetPwdSerializer(data=request.data, context={'request': request})  # 初始化序列化器并传递请求上下文
        if serializer.is_valid():  # 验证请求数据
            # 从验证后的数据中获取新密码
            pwd1 = serializer.validated_data.get('pwd1')
            # 设置用户的新密码并保存
            request.user.set_password(pwd1)
            request.user.save()
            # 密码重置成功，返回空响应体和默认的成功状态码200
            return Response({"detail": '修改密码成功'})

        else:  # 数据验证失败时
            # 打印错误信息（调试用），提取并返回第一条错误详情
            # print(serializer.errors.values())
            detail = list(serializer.errors.values())[0][0]
            return Response({"detail": detail}, status=status.HTTP_400_BAD_REQUEST)  # 返回错误响应，状态码400



