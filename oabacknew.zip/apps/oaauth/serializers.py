# 导入序列化器相关模块和自定义的模型
from rest_framework import serializers
from .models import OAUser, UserStatusChoices, OADepartment
from rest_framework import exceptions


# 登录序列化器，用于验证登录请求的数据
class LoginSerializer(serializers.Serializer):
    # 邮箱字段，必需，设置错误提示信息
    email = serializers.EmailField(required=True, error_messages={"required": "请输入邮箱！"})
    # 密码字段，限制最大最小长度
    password = serializers.CharField(max_length=20, min_length=6)

    # 重写validate方法，对输入数据进行校验
    def validate(self, attrs):
        email = attrs.get('email')  # 获取邮箱
        password = attrs.get('password')  # 获取密码

        # 邮箱和密码均不为空时进行验证
        if email and password:
            # 尝试根据邮箱获取用户，仅取第一条数据
            user = OAUser.objects.filter(email=email).first()
            # 如果未找到用户，则抛出错误
            if not user:
                raise serializers.ValidationError("请输入正确的邮箱！")
            # 验证密码是否正确
            if not user.check_password(password):
                raise serializers.ValidationError("请输入正确的密码！")
            # 根据用户状态进行检查
            if user.status == UserStatusChoices.UNACTIVE:
                raise serializers.ValidationError("该用户尚未激活！")
            elif user.status == UserStatusChoices.LOCKED:
                raise serializers.ValidationError("该用户已被锁定，请联系管理员！")
            # 验证通过，将用户对象存入attrs，便于后续处理
            attrs['user'] = user
        else:
            # 邮箱或密码为空时抛出错误
            raise serializers.ValidationError('请传入邮箱和密码！')
        # 返回验证后的数据
        return attrs


# 部门序列化器，基于ModelSerializer自动处理OADepartment模型
class DepartmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = OADepartment  # 指定序列化的模型
        fields = "__all__"  # 序列化所有字段


# 用户序列化器，展示用户信息，排除敏感字段
class UserSerializer(serializers.ModelSerializer):
    # 嵌套序列化部门信息
    department = DepartmentSerializer()

    class Meta:
        model = OAUser  # 指定序列化的模型
        # 排除password、groups、user_permissions字段，避免泄露敏感信息
        exclude = ('password', 'groups', 'user_permissions')

class ResetPwdSerializer(serializers.Serializer):
    # 旧密码字段，限制长度
    oldpwd = serializers.CharField(min_length=6, max_length=20)
    # 新密码字段，限制长度
    pwd1 = serializers.CharField(min_length=6, max_length=20)
    # 确认新密码字段，限制长度
    pwd2 = serializers.CharField(min_length=6, max_length=20)

    # 重写validate方法进行密码重置验证
    def validate(self, attrs):
        oldpwd = attrs['oldpwd']  # 获取旧密码
        pwd1 = attrs['pwd1']  # 获取新密码
        pwd2 = attrs['pwd2']  # 获取确认新密码

        # 从请求上下文中获取当前用户
        user = self.context['request'].user
        # 验证旧密码是否正确
        if not user.check_password(oldpwd):
            raise exceptions.ValidationError("旧密码错误！")

        # 验证两次输入的新密码是否一致
        if pwd1 != pwd2:
            raise exceptions.ValidationError("两个新密码不一致！")

        # 验证通过，返回处理后的数据
        return attrs

# 重置密码序列化器
class ResetPwdSerializer(serializers.Serializer):
    # 旧密码字段，限制长度
    oldpwd = serializers.CharField(min_length=6, max_length=20)
    # 新密码字段，限制长度
    pwd1 = serializers.CharField(min_length=6, max_length=20)
    # 确认新密码字段，限制长度
    pwd2 = serializers.CharField(min_length=6, max_length=20)

    # 重写validate方法进行密码重置验证
    def validate(self, attrs):
        oldpwd = attrs['oldpwd']  # 获取旧密码
        pwd1 = attrs['pwd1']  # 获取新密码
        pwd2 = attrs['pwd2']  # 获取确认新密码

        # 从请求上下文中获取当前用户
        user = self.context['request'].user
        # 验证旧密码是否正确
        if not user.check_password(oldpwd):
            raise exceptions.ValidationError("旧密码错误！")

        # 验证两次输入的新密码是否一致
        if pwd1 != pwd2:
            raise exceptions.ValidationError("两个新密码不一致！")

        # 验证通过，返回处理后的数据
        return attrs