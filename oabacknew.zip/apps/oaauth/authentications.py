# 导入必要的库和模块
import jwt  # JSON Web Tokens库，用于生成和解析JWT
import time  # 时间处理库
from django.conf import settings  # Django设置模块，用于获取SECRET_KEY等配置
from rest_framework.authentication import BaseAuthentication, get_authorization_header  # DRF认证基类及相关方法
from rest_framework import exceptions  # DRF异常处理模块
from jwt.exceptions import ExpiredSignatureError  # JWT过期异常
from .models import OAUser  # 自定义用户模型


# 生成JWT令牌的函数
def generate_jwt(user):
    # 计算令牌过期时间（当前时间+7天）
    expire_time = time.time() + 60 * 60 * 24 * 7
    # 使用Django设置中的SECRET_KEY作为签名密钥，生成JWT令牌
    return jwt.encode({"userid": user.pk, "exp": expire_time}, key=settings.SECRET_KEY)


# 用户Token认证类，继承自BaseAuthentication
class UserTokenAuthentication(BaseAuthentication):
    # 重写authenticate方法，用于认证用户
    def authenticate(self, request):
        # 从request对象中直接获取user和auth信息，通常用于已经通过其他方式验证的情况
        return request._request.user, request._request.auth


# JWT认证类，继承自BaseAuthentication
class JWTAuthentication(BaseAuthentication):
    # 定义JWT关键字，用于从请求头中识别JWT令牌
    keyword = 'JWT'

    # 重写authenticate方法，实现JWT认证逻辑
    def authenticate(self, request):
        # 获取请求头中的Authorization部分，并分割成数组
        auth = get_authorization_header(request).split()

        # 检查JWT认证头是否存在且格式正确
        if not auth or auth[0].lower() != self.keyword.lower().encode():
            return None

        # 验证JWT认证头的格式，确保其不为空且只包含一个空格分隔的JWT令牌
        if len(auth) == 1:
            msg = "不可用的JWT请求头！"
            raise exceptions.AuthenticationFailed(msg)
        elif len(auth) > 2:
            msg = '不可用的JWT请求头！JWT Token中间不应该有空格！'
            raise exceptions.AuthenticationFailed(msg)

        try:
            # 提取JWT令牌字符串
            jwt_token = auth[1]
            # 解析JWT令牌，验证其有效性及过期时间
            jwt_info = jwt.decode(jwt_token, settings.SECRET_KEY, algorithms='HS256')
            # 从JWT载荷中获取用户ID
            userid = jwt_info.get('userid')
            try:
                # 尝试根据用户ID获取用户对象，绑定到request对象上以便后续使用
                user = OAUser.objects.get(pk=userid)
                setattr(request, 'user', user)
                # 认证成功，返回用户对象和JWT令牌
                return user, jwt_token
            except Exception:
                # 如果根据用户ID找不到用户，则认证失败
                msg = '用户不存在！'
                raise exceptions.AuthenticationFailed(msg)
        except ExpiredSignatureError:
            # 如果JWT令牌已过期，则抛出认证失败异常
            msg = "JWT Token已过期！"
            raise exceptions.AuthenticationFailed(msg)
